export interface ContactForm {
  name: string;
  email: string;
  phone: string;
  hospitalName: string;
  location: string;
  specification: string;
}