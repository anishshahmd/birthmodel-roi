import React from 'react';
import Calculator from './pages/Calculator';

function App() {
  return <Calculator />;
}

export default App;